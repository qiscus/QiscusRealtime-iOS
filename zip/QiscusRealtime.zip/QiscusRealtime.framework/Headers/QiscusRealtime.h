//
//  QiscusRealtime.h
//  QiscusRealtime
//
//  Created by Qiscus on 27/08/18.
//  Copyright © 2018 qiscus. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for QiscusRealtime.
FOUNDATION_EXPORT double QiscusRealtimeVersionNumber;

//! Project version string for QiscusRealtime.
FOUNDATION_EXPORT const unsigned char QiscusRealtimeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QiscusRealtime/PublicHeader.h>


